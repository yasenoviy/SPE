﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace lab02task1
{
    public partial class Form1 : Form
    {
        public static string database = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=atelie_mode;MultipleActiveResultSets=True;Integrated Security=True";
        public static string addservstore = "";
        public Form1()
        {
            InitializeComponent();
            this.BackgroundImage = Properties.Resources.bgimage;
            using (SqlConnection conn = new SqlConnection(database))
            {

                conn.Open();
                SqlDataReader r = (new SqlCommand("SELECT * from Category", conn)).ExecuteReader();
                int rows = 0;
                while (r.Read()) { CategoryComboBox.Items.Add(r[1].ToString()); rows++; }
                r.Close();
                if (rows >= 2)
                    textresult.Text = "Category table OK (2 rows are present)\n\n";
                else
                {
                    new SqlCommand("DELETE Category", conn).ExecuteNonQuery(); // ? 
                    new SqlCommand("INSERT Category VALUES('Європа', 'Азіатський регіон')", conn).ExecuteNonQuery();
                    new SqlCommand("INSERT Category VALUES('Азія', 'Азіатський регіон')", conn).ExecuteNonQuery();
                    textresult.Text += "added 2 initial rows\n";
                }
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void serchID_CheckedChanged(object sender, EventArgs e)
        {
            if (searchCategory.Checked && searchID.Checked)
                searchCategory.Checked = false;
        }

        private void searchtitle_CheckedChanged(object sender, EventArgs e)
        {
            if (searchCategory.Checked && searchID.Checked)
                searchID.Checked = false;
        }

        private void buttform2_Click(object sender, EventArgs e)
        {
            category categories = new category();
            this.Hide();
            if (categories.ShowDialog() == DialogResult.Cancel)
            {
                using (SqlConnection conn = new SqlConnection(database))
                {
                    CategoryComboBox.Items.Clear();
                    conn.Open();
                    SqlDataReader r = (new SqlCommand("SELECT Name from Category", conn)).ExecuteReader();
                    //?
                    while (r.Read())
                        CategoryComboBox.Items.Add(r[0].ToString());
                }
                Show();
            }
        }
        public bool PassFormat(string p)
        {
            Regex R = new Regex("^[0-9]{1,4}$");
            Match M = R.Match(p);
            return M.Success;
        }

        private void buttsearch_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(database))
            {
                string command = null;
                conn.Open();
                if (radpoluchit.Checked)
                {
                    if (searchCategory.Checked)
                    {
                        if (CategoryComboBox.Text != "")
                        {
                            command = $"SELECT * FROM atnic_ambasador WHERE atnic_ambasador.conID = (SELECT Category.ID FROM Category WHERE Category.Name = '{CategoryComboBox.SelectedItem.ToString()}') ";
                            SqlDataReader r = (new SqlCommand(command, conn)).ExecuteReader();
                            textresult.Text += $"RecordsAffected {r.RecordsAffected}\n\n";
                            textresult.Text += "|   ID   |      Country      |    Region   |  Square  |   Year  |\n" +
                                               "|-----------------------------------------------------------------------|\n";
                            while (r.Read())
                            {
                                textresult.Text += $"|   {r[0].ToString()}     |    {r[1].ToString()}    |  {r[3].ToString()}" +
                                    $"   |    {r[4].ToString()}    |        {r[5].ToString()}         |\n";
                            }
                        }
                        else
                        {
                            textresult.Text += "Не найдено!\n";
                        }
                    }
                    if (searchID.Checked)
                    {
                        if (PassFormat(textid.Text))
                        {
                            command = $"SELECT * FROM atnic_ambasador WHERE ID = {textid.Text}";
                            SqlDataReader r = (new SqlCommand(command, conn)).ExecuteReader();
                            textresult.Text += $"RecordsAffected {r.RecordsAffected}\n\n";
                            while (r.Read())
                            {
                                textid.Text = r[0].ToString();
                                textname.Text = r[1].ToString();
                                textcountry.Text = r[3].ToString();
                                textdes.Text = r[4].ToString();
                                textcal.Text = r[5].ToString();
                            }
                        }
                        else
                            textresult.Text += "Ошибка! Неверный ввод!\n";
                    }
                    if (!searchID.Checked && !searchCategory.Checked)
                    {
                        command = $"SELECT * FROM atnic_ambasador INNER JOIN Category ON atnic_ambasador.conID = Category.ID";
                        SqlDataReader r = (new SqlCommand(command, conn)).ExecuteReader();
                        textresult.Text += $"RecordsAffected {r.RecordsAffected}\n\n";
                        // !!
                        textresult.Text += "|   ID   |          Name         |  Description   |           Category         |\n" +
                                        "|-----------------------------------------------------------------------------------|\n";
                        while (r.Read())
                        {
                            textresult.Text += $"|{r[0].ToString(),4}|{r[1].ToString(),15}|{r[4].ToString(),10}" +
                                $"|{r[7].ToString(),10}|\n";
                        }
                    }

                }
                if (radadd.Checked)
                {
                    if (textid.Text != "" && textdes.Text != "")
                    {
                        string temp = null;
                        SqlDataReader b = (new SqlCommand($"SELECT ID FROM Category WHERE Category.Name = '{CategoryComboBox.SelectedItem.ToString()}'", conn)).ExecuteReader();
                        while (b.Read())
                        { temp = b[0].ToString(); }
                        b.Close();
                        new SqlCommand($"INSERT atnic_ambasador VALUES ('{textname.Text}', '{textcountry.Text}', '{textdes.Text}','{temp}', '{textcal.Text}')", conn).ExecuteNonQuery();
                        textresult.Text += "Успешно добавлена 1-на запись!\n";
                    }
                    else
                        textresult.Text += "Ошибка! Проверьте правильность ввода!\n";
                }
                if (raduppdate.Checked)
                {
                    if (textid.Text != "" && textdes.Text != "")
                    {
                        string temp = null;
                        //string a = 
                        SqlDataReader b = (new SqlCommand($"SELECT ID FROM Category WHERE Category.Name = '{CategoryComboBox.SelectedItem.ToString()}'", conn)).ExecuteReader();
                        while (b.Read())
                        { temp = b[0].ToString(); }
                        b.Close();
                        new SqlCommand($"UPDATE atnic_ambasador SET country = '{textname.Text}', region = '{textcountry.Text}', square = '{textdes.Text}',  conID = '{temp}', year = '{textcal.Text}' WHERE ID = '{textid.Text}'", conn).ExecuteNonQuery();
                        textresult.Text += "Успешно обновлена 1-на запись!\n";
                    }
                    else
                        textresult.Text += "Ошибка! Проверьте правильность ввода!\n";
                }
                if (raddel.Checked)
                {
                    if (PassFormat(textid.Text))
                    {
                        SqlDataReader b = (new SqlCommand($"SELECT * FROM atnic_ambasador WHERE ID = '{textid.Text}'", conn)).ExecuteReader();
                        if (b.HasRows)
                        {
                            textresult.Text += $"Успешно удалена 1-на запись!\nRecordsAffected {b.RecordsAffected}\n";
                            b.Close();
                            new SqlCommand($"DELETE FROM atnic_ambasador WHERE ID = {textid.Text}", conn).ExecuteNonQuery();
                            NullFields();
                        }
                        else
                            textresult.Text += "ID не найден!\n";
                    }
                    else
                        textresult.Text += "Ошибка! Проверьте правильность ввода!\n";
                }


            }
        }
        private void NullFields()
        {
            textid.Text = null;
            textname.Text = null;
            textcountry.Text = null;
            textdes.Text = null;
            textcal.Text = null;
            CategoryComboBox.SelectedText = null;
        }

        private void textresult_TextChanged(object sender, EventArgs e)
        {
            textresult.SelectionStart = textresult.TextLength;
            textresult.ScrollToCaret();
        }

        private void radadd_CheckedChanged(object sender, EventArgs e)
        {
            if (radadd.Checked)
            { textid.ReadOnly = true; addservstore = textid.Text; textid.Text = "auto"; }
            if (!radadd.Checked)
            { textid.ReadOnly = false; textid.Text = addservstore; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void deslab_Click(object sender, EventArgs e)
        {

        }

        private void callab_Click(object sender, EventArgs e)
        {

        }

        private void radpoluchit_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void labstravy_Click(object sender, EventArgs e)
        {

        }
    }
}
