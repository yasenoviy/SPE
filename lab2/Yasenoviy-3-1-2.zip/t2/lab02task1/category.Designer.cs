﻿namespace lab02task1
{
    partial class category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radpoluchit = new System.Windows.Forms.RadioButton();
            this.radadd = new System.Windows.Forms.RadioButton();
            this.raduppdate = new System.Windows.Forms.RadioButton();
            this.raddel = new System.Windows.Forms.RadioButton();
            this.labcat = new System.Windows.Forms.Label();
            this.labid = new System.Windows.Forms.Label();
            this.labname = new System.Windows.Forms.Label();
            this.labdes = new System.Windows.Forms.Label();
            this.textid = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.textdes = new System.Windows.Forms.TextBox();
            this.buttback = new System.Windows.Forms.Button();
            this.buttsearch = new System.Windows.Forms.Button();
            this.labresult = new System.Windows.Forms.Label();
            this.textresult = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radpoluchit
            // 
            this.radpoluchit.AutoSize = true;
            this.radpoluchit.BackColor = System.Drawing.Color.Transparent;
            this.radpoluchit.Checked = true;
            this.radpoluchit.Location = new System.Drawing.Point(12, 154);
            this.radpoluchit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radpoluchit.Name = "radpoluchit";
            this.radpoluchit.Size = new System.Drawing.Size(182, 21);
            this.radpoluchit.TabIndex = 1;
            this.radpoluchit.TabStop = true;
            this.radpoluchit.Text = "Отримання всіх кагорій";
            this.radpoluchit.UseVisualStyleBackColor = false;
            // 
            // radadd
            // 
            this.radadd.AutoSize = true;
            this.radadd.BackColor = System.Drawing.Color.Transparent;
            this.radadd.Location = new System.Drawing.Point(12, 181);
            this.radadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radadd.Name = "radadd";
            this.radadd.Size = new System.Drawing.Size(79, 21);
            this.radadd.TabIndex = 2;
            this.radadd.Text = "Додати";
            this.radadd.UseVisualStyleBackColor = false;
            this.radadd.CheckedChanged += new System.EventHandler(this.radadd_CheckedChanged);
            // 
            // raduppdate
            // 
            this.raduppdate.AutoSize = true;
            this.raduppdate.BackColor = System.Drawing.Color.Transparent;
            this.raduppdate.Location = new System.Drawing.Point(12, 208);
            this.raduppdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raduppdate.Name = "raduppdate";
            this.raduppdate.Size = new System.Drawing.Size(86, 21);
            this.raduppdate.TabIndex = 3;
            this.raduppdate.Text = "Оновити";
            this.raduppdate.UseVisualStyleBackColor = false;
            this.raduppdate.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // raddel
            // 
            this.raddel.AutoSize = true;
            this.raddel.BackColor = System.Drawing.Color.Transparent;
            this.raddel.Location = new System.Drawing.Point(12, 235);
            this.raddel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raddel.Name = "raddel";
            this.raddel.Size = new System.Drawing.Size(92, 21);
            this.raddel.TabIndex = 4;
            this.raddel.Text = "Вилучити";
            this.raddel.UseVisualStyleBackColor = false;
            this.raddel.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // labcat
            // 
            this.labcat.AutoSize = true;
            this.labcat.BackColor = System.Drawing.Color.Transparent;
            this.labcat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labcat.Location = new System.Drawing.Point(303, 25);
            this.labcat.Name = "labcat";
            this.labcat.Size = new System.Drawing.Size(195, 48);
            this.labcat.TabIndex = 5;
            this.labcat.Text = "Категорії";
            this.labcat.Click += new System.EventHandler(this.labdirect_Click);
            // 
            // labid
            // 
            this.labid.AutoSize = true;
            this.labid.BackColor = System.Drawing.Color.Transparent;
            this.labid.Location = new System.Drawing.Point(283, 132);
            this.labid.Name = "labid";
            this.labid.Size = new System.Drawing.Size(21, 17);
            this.labid.TabIndex = 6;
            this.labid.Text = "ID";
            // 
            // labname
            // 
            this.labname.AutoSize = true;
            this.labname.BackColor = System.Drawing.Color.Transparent;
            this.labname.Location = new System.Drawing.Point(375, 132);
            this.labname.Name = "labname";
            this.labname.Size = new System.Drawing.Size(45, 17);
            this.labname.TabIndex = 7;
            this.labname.Text = "Name";
            this.labname.Click += new System.EventHandler(this.labname1_Click);
            // 
            // labdes
            // 
            this.labdes.AutoSize = true;
            this.labdes.BackColor = System.Drawing.Color.Transparent;
            this.labdes.Location = new System.Drawing.Point(534, 132);
            this.labdes.Name = "labdes";
            this.labdes.Size = new System.Drawing.Size(79, 17);
            this.labdes.TabIndex = 9;
            this.labdes.Text = "Description";
            // 
            // textid
            // 
            this.textid.Location = new System.Drawing.Point(269, 164);
            this.textid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textid.Name = "textid";
            this.textid.Size = new System.Drawing.Size(53, 22);
            this.textid.TabIndex = 10;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(344, 164);
            this.textname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(103, 22);
            this.textname.TabIndex = 11;
            // 
            // textdes
            // 
            this.textdes.Location = new System.Drawing.Point(453, 164);
            this.textdes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textdes.Name = "textdes";
            this.textdes.Size = new System.Drawing.Size(249, 22);
            this.textdes.TabIndex = 13;
            // 
            // buttback
            // 
            this.buttback.Location = new System.Drawing.Point(49, 354);
            this.buttback.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttback.Name = "buttback";
            this.buttback.Size = new System.Drawing.Size(108, 47);
            this.buttback.TabIndex = 14;
            this.buttback.Text = "Назад";
            this.buttback.UseVisualStyleBackColor = true;
            this.buttback.Click += new System.EventHandler(this.buttback_Click);
            // 
            // buttsearch
            // 
            this.buttsearch.Location = new System.Drawing.Point(49, 287);
            this.buttsearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttsearch.Name = "buttsearch";
            this.buttsearch.Size = new System.Drawing.Size(108, 47);
            this.buttsearch.TabIndex = 15;
            this.buttsearch.Text = "Виконати запит";
            this.buttsearch.UseVisualStyleBackColor = true;
            this.buttsearch.Click += new System.EventHandler(this.buttsearch_Click);
            // 
            // labresult
            // 
            this.labresult.AutoSize = true;
            this.labresult.BackColor = System.Drawing.Color.Transparent;
            this.labresult.Location = new System.Drawing.Point(375, 212);
            this.labresult.Name = "labresult";
            this.labresult.Size = new System.Drawing.Size(203, 17);
            this.labresult.TabIndex = 16;
            this.labresult.Text = "Результат останнього запиту";
            // 
            // textresult
            // 
            this.textresult.Location = new System.Drawing.Point(237, 257);
            this.textresult.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textresult.Name = "textresult";
            this.textresult.ReadOnly = true;
            this.textresult.Size = new System.Drawing.Size(464, 132);
            this.textresult.TabIndex = 17;
            this.textresult.Text = "";
            this.textresult.TextChanged += new System.EventHandler(this.textresult_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lab02task1.Properties.Resources.photo_2021_07_11_12_18_41;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // category
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 431);
            this.Controls.Add(this.textresult);
            this.Controls.Add(this.labresult);
            this.Controls.Add(this.buttsearch);
            this.Controls.Add(this.buttback);
            this.Controls.Add(this.textdes);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.textid);
            this.Controls.Add(this.labdes);
            this.Controls.Add(this.labname);
            this.Controls.Add(this.labid);
            this.Controls.Add(this.labcat);
            this.Controls.Add(this.raddel);
            this.Controls.Add(this.raduppdate);
            this.Controls.Add(this.radadd);
            this.Controls.Add(this.radpoluchit);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "category";
            this.Text = "categories";
            this.Load += new System.EventHandler(this.directors_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton radpoluchit;
        private System.Windows.Forms.RadioButton radadd;
        private System.Windows.Forms.RadioButton raduppdate;
        private System.Windows.Forms.RadioButton raddel;
        private System.Windows.Forms.Label labcat;
        private System.Windows.Forms.Label labid;
        private System.Windows.Forms.Label labname;
        private System.Windows.Forms.Label labdes;
        private System.Windows.Forms.TextBox textid;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textdes;
        private System.Windows.Forms.Button buttback;
        private System.Windows.Forms.Button buttsearch;
        private System.Windows.Forms.Label labresult;
        private System.Windows.Forms.RichTextBox textresult;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}