﻿namespace lab02task1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.labstravy = new System.Windows.Forms.Label();
            this.radpoluchit = new System.Windows.Forms.RadioButton();
            this.searchID = new System.Windows.Forms.CheckBox();
            this.textid = new System.Windows.Forms.TextBox();
            this.buttsearch = new System.Windows.Forms.Button();
            this.radadd = new System.Windows.Forms.RadioButton();
            this.raduppdate = new System.Windows.Forms.RadioButton();
            this.raddel = new System.Windows.Forms.RadioButton();
            this.searchCategory = new System.Windows.Forms.CheckBox();
            this.idlab = new System.Windows.Forms.Label();
            this.namelab = new System.Windows.Forms.Label();
            this.deslab = new System.Windows.Forms.Label();
            this.callab = new System.Windows.Forms.Label();
            this.textname = new System.Windows.Forms.TextBox();
            this.textdes = new System.Windows.Forms.TextBox();
            this.textcal = new System.Windows.Forms.TextBox();
            this.buttform2 = new System.Windows.Forms.Button();
            this.CategoryComboBox = new System.Windows.Forms.ComboBox();
            this.countrylab = new System.Windows.Forms.Label();
            this.textcountry = new System.Windows.Forms.TextBox();
            this.textresult = new System.Windows.Forms.RichTextBox();
            this.resultlab = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labstravy
            // 
            this.labstravy.AutoSize = true;
            this.labstravy.BackColor = System.Drawing.Color.Transparent;
            this.labstravy.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labstravy.Location = new System.Drawing.Point(223, 25);
            this.labstravy.Name = "labstravy";
            this.labstravy.Size = new System.Drawing.Size(302, 48);
            this.labstravy.TabIndex = 1;
            this.labstravy.Text = "Античні країни";
            // 
            // radpoluchit
            // 
            this.radpoluchit.AutoSize = true;
            this.radpoluchit.BackColor = System.Drawing.Color.Transparent;
            this.radpoluchit.Checked = true;
            this.radpoluchit.Location = new System.Drawing.Point(13, 143);
            this.radpoluchit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radpoluchit.Name = "radpoluchit";
            this.radpoluchit.Size = new System.Drawing.Size(169, 21);
            this.radpoluchit.TabIndex = 2;
            this.radpoluchit.TabStop = true;
            this.radpoluchit.Text = "Отримання всіх країн";
            this.radpoluchit.UseVisualStyleBackColor = false;
            // 
            // searchID
            // 
            this.searchID.AutoSize = true;
            this.searchID.BackColor = System.Drawing.Color.Transparent;
            this.searchID.Location = new System.Drawing.Point(221, 144);
            this.searchID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchID.Name = "searchID";
            this.searchID.Size = new System.Drawing.Size(110, 21);
            this.searchID.TabIndex = 3;
            this.searchID.Text = "За ID країни";
            this.searchID.UseVisualStyleBackColor = false;
            this.searchID.CheckedChanged += new System.EventHandler(this.serchID_CheckedChanged);
            // 
            // textid
            // 
            this.textid.Location = new System.Drawing.Point(45, 318);
            this.textid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textid.Name = "textid";
            this.textid.Size = new System.Drawing.Size(49, 22);
            this.textid.TabIndex = 4;
            // 
            // buttsearch
            // 
            this.buttsearch.Location = new System.Drawing.Point(29, 370);
            this.buttsearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttsearch.Name = "buttsearch";
            this.buttsearch.Size = new System.Drawing.Size(83, 36);
            this.buttsearch.TabIndex = 5;
            this.buttsearch.Text = "Виконати";
            this.buttsearch.UseVisualStyleBackColor = true;
            this.buttsearch.Click += new System.EventHandler(this.buttsearch_Click);
            // 
            // radadd
            // 
            this.radadd.AutoSize = true;
            this.radadd.BackColor = System.Drawing.Color.Transparent;
            this.radadd.Location = new System.Drawing.Point(12, 170);
            this.radadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radadd.Name = "radadd";
            this.radadd.Size = new System.Drawing.Size(149, 21);
            this.radadd.TabIndex = 7;
            this.radadd.Text = "Додавання країни";
            this.radadd.UseVisualStyleBackColor = false;
            this.radadd.CheckedChanged += new System.EventHandler(this.radadd_CheckedChanged);
            // 
            // raduppdate
            // 
            this.raduppdate.AutoSize = true;
            this.raduppdate.BackColor = System.Drawing.Color.Transparent;
            this.raduppdate.Location = new System.Drawing.Point(12, 197);
            this.raduppdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raduppdate.Name = "raduppdate";
            this.raduppdate.Size = new System.Drawing.Size(149, 21);
            this.raduppdate.TabIndex = 8;
            this.raduppdate.Text = "Оновлення країни";
            this.raduppdate.UseVisualStyleBackColor = false;
            // 
            // raddel
            // 
            this.raddel.AutoSize = true;
            this.raddel.BackColor = System.Drawing.Color.Transparent;
            this.raddel.Location = new System.Drawing.Point(12, 224);
            this.raddel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raddel.Name = "raddel";
            this.raddel.Size = new System.Drawing.Size(147, 21);
            this.raddel.TabIndex = 9;
            this.raddel.Text = "Вилучення країни";
            this.raddel.UseVisualStyleBackColor = false;
            // 
            // searchCategory
            // 
            this.searchCategory.AutoSize = true;
            this.searchCategory.BackColor = System.Drawing.Color.Transparent;
            this.searchCategory.Location = new System.Drawing.Point(403, 143);
            this.searchCategory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchCategory.Name = "searchCategory";
            this.searchCategory.Size = new System.Drawing.Size(122, 21);
            this.searchCategory.TabIndex = 10;
            this.searchCategory.Text = "За категорією";
            this.searchCategory.UseVisualStyleBackColor = false;
            this.searchCategory.CheckedChanged += new System.EventHandler(this.searchtitle_CheckedChanged);
            // 
            // idlab
            // 
            this.idlab.AutoSize = true;
            this.idlab.BackColor = System.Drawing.Color.Transparent;
            this.idlab.Location = new System.Drawing.Point(57, 286);
            this.idlab.Name = "idlab";
            this.idlab.Size = new System.Drawing.Size(21, 17);
            this.idlab.TabIndex = 11;
            this.idlab.Text = "ID";
            // 
            // namelab
            // 
            this.namelab.AutoSize = true;
            this.namelab.BackColor = System.Drawing.Color.Transparent;
            this.namelab.Location = new System.Drawing.Point(140, 286);
            this.namelab.Name = "namelab";
            this.namelab.Size = new System.Drawing.Size(57, 17);
            this.namelab.TabIndex = 12;
            this.namelab.Text = "Country";
            this.namelab.Click += new System.EventHandler(this.label3_Click);
            // 
            // deslab
            // 
            this.deslab.AutoSize = true;
            this.deslab.BackColor = System.Drawing.Color.Transparent;
            this.deslab.Location = new System.Drawing.Point(323, 286);
            this.deslab.Name = "deslab";
            this.deslab.Size = new System.Drawing.Size(54, 17);
            this.deslab.TabIndex = 14;
            this.deslab.Text = "Square";
            // 
            // callab
            // 
            this.callab.AutoSize = true;
            this.callab.BackColor = System.Drawing.Color.Transparent;
            this.callab.Location = new System.Drawing.Point(423, 286);
            this.callab.Name = "callab";
            this.callab.Size = new System.Drawing.Size(38, 17);
            this.callab.TabIndex = 15;
            this.callab.Text = "Year";
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(120, 318);
            this.textname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(84, 22);
            this.textname.TabIndex = 16;
            this.textname.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textdes
            // 
            this.textdes.Location = new System.Drawing.Point(303, 318);
            this.textdes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textdes.Name = "textdes";
            this.textdes.Size = new System.Drawing.Size(89, 22);
            this.textdes.TabIndex = 17;
            // 
            // textcal
            // 
            this.textcal.Location = new System.Drawing.Point(403, 318);
            this.textcal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textcal.Name = "textcal";
            this.textcal.Size = new System.Drawing.Size(73, 22);
            this.textcal.TabIndex = 18;
            this.textcal.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // buttform2
            // 
            this.buttform2.Location = new System.Drawing.Point(29, 426);
            this.buttform2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttform2.Name = "buttform2";
            this.buttform2.Size = new System.Drawing.Size(83, 34);
            this.buttform2.TabIndex = 19;
            this.buttform2.Text = "Категорії";
            this.buttform2.UseVisualStyleBackColor = true;
            this.buttform2.Click += new System.EventHandler(this.buttform2_Click);
            // 
            // CategoryComboBox
            // 
            this.CategoryComboBox.FormattingEnabled = true;
            this.CategoryComboBox.Location = new System.Drawing.Point(501, 315);
            this.CategoryComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CategoryComboBox.Name = "CategoryComboBox";
            this.CategoryComboBox.Size = new System.Drawing.Size(145, 24);
            this.CategoryComboBox.TabIndex = 20;
            // 
            // countrylab
            // 
            this.countrylab.AutoSize = true;
            this.countrylab.BackColor = System.Drawing.Color.Transparent;
            this.countrylab.Location = new System.Drawing.Point(227, 286);
            this.countrylab.Name = "countrylab";
            this.countrylab.Size = new System.Drawing.Size(53, 17);
            this.countrylab.TabIndex = 21;
            this.countrylab.Text = "Region";
            this.countrylab.Click += new System.EventHandler(this.countrylab_Click);
            // 
            // textcountry
            // 
            this.textcountry.Location = new System.Drawing.Point(221, 318);
            this.textcountry.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textcountry.Name = "textcountry";
            this.textcountry.Size = new System.Drawing.Size(63, 22);
            this.textcountry.TabIndex = 22;
            // 
            // textresult
            // 
            this.textresult.Location = new System.Drawing.Point(159, 377);
            this.textresult.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textresult.Name = "textresult";
            this.textresult.ReadOnly = true;
            this.textresult.Size = new System.Drawing.Size(488, 146);
            this.textresult.TabIndex = 23;
            this.textresult.Text = "";
            this.textresult.TextChanged += new System.EventHandler(this.textresult_TextChanged);
            // 
            // resultlab
            // 
            this.resultlab.AutoSize = true;
            this.resultlab.BackColor = System.Drawing.Color.Transparent;
            this.resultlab.Location = new System.Drawing.Point(332, 354);
            this.resultlab.Name = "resultlab";
            this.resultlab.Size = new System.Drawing.Size(129, 17);
            this.resultlab.TabIndex = 24;
            this.resultlab.Text = "Результат запиту:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lab02task1.Properties.Resources.photo_2020_03_28_14_32_25;
            this.pictureBox1.Location = new System.Drawing.Point(13, 25);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 535);
            this.Controls.Add(this.resultlab);
            this.Controls.Add(this.textresult);
            this.Controls.Add(this.textcountry);
            this.Controls.Add(this.countrylab);
            this.Controls.Add(this.CategoryComboBox);
            this.Controls.Add(this.buttform2);
            this.Controls.Add(this.textcal);
            this.Controls.Add(this.textdes);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.callab);
            this.Controls.Add(this.deslab);
            this.Controls.Add(this.namelab);
            this.Controls.Add(this.idlab);
            this.Controls.Add(this.searchCategory);
            this.Controls.Add(this.raddel);
            this.Controls.Add(this.raduppdate);
            this.Controls.Add(this.radadd);
            this.Controls.Add(this.buttsearch);
            this.Controls.Add(this.textid);
            this.Controls.Add(this.searchID);
            this.Controls.Add(this.radpoluchit);
            this.Controls.Add(this.labstravy);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labstravy;
        private System.Windows.Forms.RadioButton radpoluchit;
        private System.Windows.Forms.CheckBox searchID;
        private System.Windows.Forms.TextBox textid;
        private System.Windows.Forms.Button buttsearch;
        private System.Windows.Forms.RadioButton radadd;
        private System.Windows.Forms.RadioButton raduppdate;
        private System.Windows.Forms.RadioButton raddel;
        private System.Windows.Forms.CheckBox searchCategory;
        private System.Windows.Forms.Label idlab;
        private System.Windows.Forms.Label namelab;
        private System.Windows.Forms.Label deslab;
        private System.Windows.Forms.Label callab;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textdes;
        private System.Windows.Forms.TextBox textcal;
        private System.Windows.Forms.Button buttform2;
        private System.Windows.Forms.ComboBox CategoryComboBox;
        private System.Windows.Forms.Label countrylab;
        private System.Windows.Forms.TextBox textcountry;
        private System.Windows.Forms.RichTextBox textresult;
        private System.Windows.Forms.Label resultlab;
    }
}

