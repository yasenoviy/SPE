﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab02task1
{
    public partial class category : Form
    {
        public category()
        {
            InitializeComponent();
            this.BackgroundImage = Properties.Resources.bgimage;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void buttsearch_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(Form1.database))
            {
                string command = null;
                conn.Open();
                if (radpoluchit.Checked)
                {
                    command = $"SELECT * FROM Category";
                    MySqlDataReader r = (new MySqlCommand(command, conn)).ExecuteReader();
                    textresult.Text += $"RecordsAffected {r.RecordsAffected}\n\n";
                    textresult.Text += "|   ID    |         Name       |    Description    |\n" +
                                       "|--------------------------------------------------------------------------------------|\n";
                    while (r.Read())
                    {
                        textresult.Text += $"|  {r[0].ToString()}    |{r[1].ToString(),10}   |{r[2].ToString(),20}  |\n";

                    }

                }
                if (radadd.Checked)
                {
                    //if (PassFormat(cost_serv.Text, Type.Number) && PassFormat(rate_serv.Text, Type.Rating))
                    //{
                    if (textid.Text != "" && textdes.Text != "")
                    {
                        new MySqlCommand($"INSERT into Category (Name, `desc`) VALUES ('{textname.Text}', '{textdes.Text}')", conn).ExecuteNonQuery();
                        textresult.Text += $"Успешно добавлена 1-на запись!";
                    }
                    else
                        textresult.Text += "\nВсе поля должны быть заполнены!\n";

                    //}
                }


                if (raduppdate.Checked)
                {
                    //if (PassFormat(desc1_dep.Text, Type.Number) && PassFormat(rate_serv.Text, Type.Rating))
                    //{
                    if (textid.Text != "" && textdes.Text != "")
                    {
                        new MySqlCommand($"UPDATE Category SET Name = '{textname.Text}', `desc` = '{textdes.Text}' WHERE ID = '{textid.Text}'", conn).ExecuteNonQuery();
                        textresult.Text += "Успешно обновлена 1-на запись!";
                    }
                    else
                        textresult.Text += "\nВсе поля должны быть заполнены!\n";

                    //}
                    //else
                    //   res_rtb.Text += "Ошибка! Проверьте правильность ввода!\n";
                }
                if (raddel.Checked)
                {
                    if (PassFormat(textid.Text))
                    {
                        MySqlDataReader b = (new MySqlCommand($"SELECT * FROM Category WHERE ID = '{textid.Text}'", conn)).ExecuteReader();
                        if (b.HasRows)
                        {
                            textresult.Text += $"Успешно удалена 1-на запись!\nRecordsAffected {b.RecordsAffected}\n";
                            b.Close();
                            new MySqlCommand($"DELETE FROM Category WHERE ID = {textid.Text}", conn).ExecuteNonQuery();
                            textid.Text = null; textname.Text = null; textdes.Text = null;
                        }
                        else
                            textresult.Text += "\nID не найден!\n";
                    }
                    else
                        textresult.Text += "Ошибка! Проверьте правильность ввода!\n";
                }
            }
        }
        public bool PassFormat(string p)
        {
            Regex R = new Regex("^[0-9]{1,4}$");
            Match M = R.Match(p);
            return M.Success;
        }
        private void directors_Load(object sender, EventArgs e)
        {

        }

        private void textresult_TextChanged(object sender, EventArgs e)
        {
            textresult.SelectionStart = textresult.TextLength;
            textresult.ScrollToCaret();
        }

        private void radadd_CheckedChanged(object sender, EventArgs e)
        {
            if (radadd.Checked)
            { textid.ReadOnly = true; Form1.addservstore = textid.Text; textid.Text = "auto"; }
            if (!radadd.Checked)
            { textid.ReadOnly = false; textid.Text = Form1.addservstore; }
        }

        private void buttback_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labdirect_Click(object sender, EventArgs e)
        {

        }

        private void labname1_Click(object sender, EventArgs e)
        {

        }
    }
}
