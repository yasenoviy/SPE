﻿using System.Net.Mail;
using System.Net;
using System;

namespace Lab1_4
{
    class task4
    {
        static void Main(string[] args)
        {
            if (args.Length == 2)
            {
                Console.WriteLine("Відправка");
                string message = DateTime.Now.ToString("d MMM  HH:mm:ss");
                Console.WriteLine(message);
                Console.WriteLine("Ясеновий Артем");

                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("ayasenoviy@knu.ua", "ombjdtdnyfesocga"),
                    EnableSsl = true,
                };

                //troll.com.ua@ukr.net
                //ayasenoviy@knu.ua
                //smtpClient.Send("troll.com.ua@ukr.net", args[0], args[1], message);
                smtpClient.Send("ayasenoviy@knu.ua", args[0], args[1], message);
                Console.WriteLine("Успiшно!");
                Console.ReadKey();

            }
            else
            {
                Console.Write("Недостатньо аргументів, застосування: <пошта> <тема>");
                Console.ReadKey();
            }
        }
    }
}
