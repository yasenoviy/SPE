﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace lab1_1
{
    class Program
    {

        static void Main(string[] args)
        {
            // File data
            string file1 = @"C:\Users\troll\Desktop\3_1\SPE\lsmod.txt";
            string file2 = @"C:\Users\troll\Desktop\3_1\SPE\lsmod_light.txt";
            string link = @"https://mail.univ.net.ua/lsmod.txt";
            string del_str = @"floppy"; 

             // file check and delete
             FileInfo fileInfo1 = new FileInfo(file1);
            FileInfo fileInfo2 = new FileInfo(file2);
            if (fileInfo1.Exists) 
            {
                fileInfo1.Delete();
                Console.WriteLine("***Delete lsmod.txt***");
            }
            if (fileInfo2.Exists)
            {
                fileInfo2.Delete();
                Console.WriteLine("***Delete lsmod_light.txt***");
            }

            // downloading file
            Console.WriteLine("***Download lsmod.txt***");

            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(link);
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            Stream stream = resp.GetResponseStream();
            FileStream file = new FileStream(file1, FileMode.Create, FileAccess.Write);
            StreamWriter write = new StreamWriter(file);
            int b;
            for (int i = 0; ; i++)
            {
                b = stream.ReadByte();
                if (b == -1) break;
                write.Write((char)b);
            }
            write.Close();
            file.Close();

            // find and delete string with «dm_region»
            Console.WriteLine("***Delete string with «dm_region»***");
            
            string[] All_lines = File.ReadAllLines(file1, Encoding.Default);
            for (int i = 0; i < All_lines.Length; i++)
            {
                if (All_lines[i].Contains(del_str)) All_lines[i] = " ";
            }

            // write strings to new file 
            Console.WriteLine("***create lsmod_light.txt***");
            File.WriteAllLines(file2, All_lines);

            Console.WriteLine("***end***");
            Console.ReadKey();
        }
    }
}
